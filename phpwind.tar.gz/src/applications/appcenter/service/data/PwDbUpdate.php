<?php
/**
 * 在线升级数据库回调 
 *
 * @author Shi Long <long.shi@alibaba-inc.com>
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.windframework.com
 * @version $Id: PwDbUpdate.php 21071 2012-11-27 06:34:14Z long.shi $
 * @package appcenter
 */
class PwDbUpdate {
	
	/**
	 * 在线升级数据库回调 
	 *
	 */
	public function update() {
		
	}
}

?>